from django.urls import path, include

app_name = 'webapp'

urlpatterns = [

]


